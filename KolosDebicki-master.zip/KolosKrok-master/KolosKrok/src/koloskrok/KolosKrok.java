package koloskrok;

/**
 *
 * @author informatyka1
 */
public class KolosKrok {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
    /**
     * @param A non-empty zero-indexed array. Contains the sizes of the fish.
     * @param B non-empty zero-indexed array. Contains the tirections of the fish. Contains only 0s and/or 1s.
     * @param N number of fish in the scenario.
     * @return number of fish that will stay alive.
     */
    
    public static int ProblemRybek (int A[], int B[], int N){
        int zywe = 0;
        int stos[] = new int[N];
        int wielkoscStosu = 0;
        boolean czyRozneKierunki = true;
        
        for (int i =0; i<N; i++){
           czyRozneKierunki = true;
           
           while((wielkoscStosu > 0) && (czyRozneKierunki == true) && B[i] ==0){
               if (A [i] < stos[wielkoscStosu - 1] ) {
                    czyRozneKierunki = false;
                } else {
                    wielkoscStosu -= 1;
                }               
           }
           
           if (B[i] == 1) {
               
                stos[wielkoscStosu] = A[i];
                wielkoscStosu += 1;
                
            } else if (wielkoscStosu == 0) {
                zywe++;
            } 
           
           
           
        }

        
        
        
        return zywe;
    }

    
    
}
